<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Numero;
use App\User;

class NumeroController extends Controller
{
    public function index()
    {
        $Numero=Numero::get();
        return response()->json(['succes' =>$Numero], 200);
    }
    public function store(Request $request)
    {
        $Numero= Numero::create([
            'nom'=>$request['nom'],
            'prenom'=>$request['prenom'],
            'adresse'=>$request['adresse'],

            'telephone'=>$request['telephone'],
            'code_postale'=>$request['code_postale'],
            'date_nais'=>$request['date_nais'],
            'user_id'=>$request['user_id'],

            'statue'=>0 // Not yet copied ( 1 ==> progress the copie ) (2 ==> finsh the copie)
        ]);
            return response()->json(['Numero'=>$Numero]);
    }

    public function show($id)
    {
        $Numero=Numero::find($id)->get();
        return response()->json(['succes' => $Numero], 200);

    }
    public function showAllEmp()
    {
        $users=User::with('numero_post')->where('role',1)->get();
        return response()->json(['succes' => $users], 200);

    }
    public function showEmpById($id)
    {
        $users=User::with('numero_post')->where('role',1)->where('id',$id)->get();
        return response()->json(['succes' => $users], 200);

    }
    public function update(Request $request, $id)
    {
        $chnageNumero=Numero::where('id',$id)->update([

            'nom'=>$request['nom'],
            'prenom'=>$request['prenom'],
            'adresse'=>$request['adresse'],

            'telephone'=>$request['telephone'],
            'code_postale'=>$request['code_postale'],
            'date_nais'=>$request['date_nais'],

            
           // 'statue'=>$request['code_postale'] // Not yet copied ( 1 ==> progress the copie ) (2 ==> finsh the copie)
          
        ]);
        return response()->json(['succes' => $chnageNumero], 200);

    }
    public function updatestatue(Request $request, $id)
    {
        $chnageNumero=Numero::where('id',$id)->update([

         'statue'=>$request['statue'] // Not yet copied ( 1 ==> progress the copie ) (2 ==> finsh the copie)
          
        ]);
        return response()->json(['succes' => $chnageNumero], 200);

    }

  
    public function destroy($id)
    {
        $delete = Numero::find($id);
               
               if (!$delete) {
                return response()->json([
                    'success' => false,
                    'message' => 'Sorry, delete with id ' . $id . ' cannot be found'
                ], 400);
            }
         
            if ($delete->delete()) {
                return response()->json([
                    'success' => true ,
                    'message' => 'delete with id ' . $id . ' is deleted ',
                    'delete' => $delete
                    ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'delete could not be deleted'
                ], 500);
            }

    }

}
